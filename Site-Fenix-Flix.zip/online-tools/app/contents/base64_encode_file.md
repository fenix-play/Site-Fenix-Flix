---
title: Base64 Encode File
template: page.jade
js: https://cdn.jsdelivr.net/gh/emn178/hi-base64/build/base64.min.js
method: base64.encode
action: Encode
auto_update: true
file_input: true
description: Base64 online encode file function
keywords: Base64,online,encode,file
---
