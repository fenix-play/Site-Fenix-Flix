---
title: CRC-16
template: page.jade
js: https://cdn.jsdelivr.net/gh/emn178/js-crc/build/crc.min.js
method: crc16
action: Hash
auto_update: true
description: CRC-16 online hash function
keywords: CRC,CRC-16,online,hash
---
