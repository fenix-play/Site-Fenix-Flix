---
title: Base32 Encode
template: page.jade
js: https://cdn.jsdelivr.net/gh/emn178/hi-base32/build/base32.min.js
method: base32.encode
action: Encode
auto_update: true
description: Base32 online encode function
keywords: Base32,online,encode
---
