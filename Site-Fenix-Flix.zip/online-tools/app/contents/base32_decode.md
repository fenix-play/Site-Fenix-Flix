---
title: Base32 Decode
template: page.jade
js: https://cdn.jsdelivr.net/gh/emn178/hi-base32/build/base32.min.js
method: base32.decode
action: Decode
auto_update: true
description: Base32 online decode function
keywords: Base32,online,decode
---
